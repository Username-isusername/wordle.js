const WORD_LENGTH = 5;
const MAX_ATTEMPTS = 6;
const CONGRATULATIONS = [
    "Genius",
    "Magnificent",
    "Impressive",
    "Splendid",
    "Great",
    "Phew",
];
const FLIP_SPEED = 400;
